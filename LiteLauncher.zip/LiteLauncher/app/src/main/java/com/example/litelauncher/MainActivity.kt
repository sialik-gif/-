package com.example.litelauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.LruCache
import android.view.View
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class App(val label: String, val component: ComponentName, val ri: ResolveInfo)

class MainActivity : Activity() {

    private val io = Executors.newFixedThreadPool(2)
    private val ui = Handler(Looper.getMainLooper())
    private val cache = LruCache<String, Drawable>(150)

    private lateinit var grid: RecyclerView
    private lateinit var favRow: RecyclerView
    private lateinit var gridAdapter: AppAdapter
    private lateinit var favAdapter: AppAdapter
    private lateinit var prefs: SharedPreferences

    private var all: List<App> = emptyList()
    private val favKeys = ArrayList<String>()

    private val reload = Runnable { load() }
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            ui.removeCallbacks(reload)
            ui.postDelayed(reload, 500) // debounce
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main)

        prefs = getSharedPreferences("fav", MODE_PRIVATE)
        favKeys.addAll((prefs.getString("list", "") ?: "").split("\n").filter { it.isNotEmpty() })

        val favWidth = (170 * resources.displayMetrics.density).toInt()
        gridAdapter = AppAdapter(packageManager, io, ui, cache, 0, ::launch, ::showMenu)
        favAdapter = AppAdapter(packageManager, io, ui, cache, favWidth, ::launch, ::showMenu)

        grid = findViewById<RecyclerView>(R.id.grid).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 5)
            adapter = gridAdapter
            setHasFixedSize(true)
            setItemViewCacheSize(20)
            itemAnimator = null
        }
        favRow = findViewById<RecyclerView>(R.id.fav).apply {
            layoutManager = LinearLayoutManager(this@MainActivity, LinearLayoutManager.HORIZONTAL, false)
            adapter = favAdapter
            itemAnimator = null
        }

        registerReceiver(receiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        })
        load()
    }

    private fun load() {
        io.execute {
            val pm = packageManager
            val seen = HashSet<String>()
            val list = ArrayList<App>()
            for (cat in arrayOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
                val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
                for (ri in pm.queryIntentActivities(q, 0)) {
                    val ai = ri.activityInfo
                    if (ai.packageName == packageName || !seen.add(ai.packageName)) continue
                    list.add(App(ri.loadLabel(pm).toString(), ComponentName(ai.packageName, ai.name), ri))
                }
            }
            list.sortBy { it.label.lowercase() }
            ui.post {
                all = list
                gridAdapter.submit(list)
                refreshFavs()
            }
        }
    }

    private fun refreshFavs() {
        val map = all.associateBy { it.component.flattenToString() }
        val list = favKeys.mapNotNull { map[it] }
        favAdapter.submit(list)
        favRow.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun showMenu(a: App) {
        val key = a.component.flattenToString()
        val pinned = key in favKeys
        val items = arrayOf(
            if (pinned) "Убрать с главного экрана" else "Добавить на главный экран",
            "О приложении"
        )
        AlertDialog.Builder(this)
            .setTitle(a.label)
            .setItems(items) { _, which ->
                if (which == 0) {
                    if (pinned) favKeys.remove(key) else favKeys.add(key)
                    prefs.edit().putString("list", favKeys.joinToString("\n")).apply()
                    refreshFavs()
                    if (favAdapter.itemCount == 0) grid.requestFocus()
                } else {
                    openInfo(a)
                }
            }
            .show()
    }

    private fun launch(a: App) {
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(a.component)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
        } catch (_: ActivityNotFoundException) {
        }
    }

    private fun openInfo(a: App) {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", a.component.packageName, null))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: ActivityNotFoundException) {
        }
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // На домашнем экране "Назад" ничего не делает
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        unregisterReceiver(receiver)
        io.shutdown()
        super.onDestroy()
    }
}
