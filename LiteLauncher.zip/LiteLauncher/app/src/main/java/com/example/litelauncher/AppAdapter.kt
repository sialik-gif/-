package com.example.litelauncher

import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Handler
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executor

class AppAdapter(
    private val pm: PackageManager,
    private val io: Executor,
    private val ui: Handler,
    private val cache: LruCache<String, Drawable>,
    private val itemWidth: Int, // 0 = на всю ширину ячейки
    private val onClick: (App) -> Unit,
    private val onLong: (App) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
        var key: String? = null
    }

    private var items: List<App> = emptyList()

    fun submit(list: List<App>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
        val v = LayoutInflater.from(p.context).inflate(R.layout.item, p, false)
        if (itemWidth > 0) v.layoutParams.width = itemWidth
        val h = VH(v)
        v.setOnClickListener {
            val i = h.bindingAdapterPosition
            if (i >= 0) onClick(items[i])
        }
        v.setOnLongClickListener {
            val i = h.bindingAdapterPosition
            if (i >= 0) onLong(items[i])
            true
        }
        return h
    }

    override fun onBindViewHolder(h: VH, pos: Int) {
        val app = items[pos]
        val key = app.component.flattenToString()
        h.key = key
        h.label.text = app.label

        val cached = cache.get(key)
        if (cached != null) {
            h.icon.setImageDrawable(cached)
            return
        }
        h.icon.setImageDrawable(null)
        io.execute {
            val d = app.ri.activityInfo.loadBanner(pm) ?: app.ri.loadIcon(pm)
            cache.put(key, d)
            ui.post { if (h.key == key) h.icon.setImageDrawable(d) }
        }
    }
}
