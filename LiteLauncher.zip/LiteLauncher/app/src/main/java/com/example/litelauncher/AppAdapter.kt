package com.example.litelauncher

import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Handler
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executor

class Icon(val d: Drawable, val banner: Boolean)

class AppAdapter(
    private val pm: PackageManager,
    private val io: Executor,
    private val ui: Handler,
    private val cache: LruCache<String, Icon>,
    private val itemWidth: Int, // 0 = ширина ячейки сетки, >0 = крупная карточка (избранное)
    private val onClick: (App) -> Unit,
    private val onLong: (App) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
        var key: String? = null
    }

    private var items: List<App> = emptyList()

    fun submit(list: List<App>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
        val v = LayoutInflater.from(p.context).inflate(R.layout.item, p, false)
        val h = VH(v)
        if (itemWidth > 0) {
            v.layoutParams.width = itemWidth
            h.icon.layoutParams.height = (itemWidth * 0.5625f).toInt()
            h.label.textSize = 16f
        }
        v.setOnClickListener {
            val i = h.bindingAdapterPosition
            if (i >= 0) onClick(items[i])
        }
        v.setOnLongClickListener {
            val i = h.bindingAdapterPosition
            if (i >= 0) onLong(items[i])
            true
        }
        return h
    }

    private fun show(h: VH, ic: Icon) {
        h.icon.setImageDrawable(ic.d)
        if (ic.banner) {
            h.icon.scaleType = ImageView.ScaleType.CENTER_CROP
            h.icon.setPadding(0, 0, 0, 0)
        } else {
            val pad = (14 * h.icon.resources.displayMetrics.density).toInt()
            h.icon.scaleType = ImageView.ScaleType.FIT_CENTER
            h.icon.setPadding(pad, pad, pad, pad)
        }
    }

    override fun onBindViewHolder(h: VH, pos: Int) {
        val app = items[pos]
        val key = app.component.flattenToString()
        h.key = key
        h.label.text = app.label

        val cached = cache.get(key)
        if (cached != null) {
            show(h, cached)
            return
        }
        h.icon.setImageDrawable(null)
        io.execute {
            val banner = app.ri.activityInfo.loadBanner(pm)
            val ic = Icon(banner ?: app.ri.loadIcon(pm), banner != null)
            cache.put(key, ic)
            ui.post { if (h.key == key) show(h, ic) }
        }
    }
}
